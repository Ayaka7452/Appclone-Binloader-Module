#!/bin/sh
# Android App Clone
# This program is able to install all apps to dual user without limits
# Powered by Ayaka7452

# Imports:
modid="App_Clone"
defpath=`cat /data/binloader/configs/defpath`
moddir=$defpath/mods/$modid
cfgfile=$moddir/defusr.cfg


envchk() {

 # Makes defusr conf file
 if [ ! -f $cfgfile ]; then
  touch $cfgfile
  echo "conf file created in moddir"
  echo "apply default dual user number"
  exit
 fi
 
 # Loads default dual user
 usrchk=`cat $cfgfile`
 case $usrchk in
 "")
  echo "empty conf found"
  echo "apply defualt dual user number"
  exit
  ;;
 *)
  # Check if it is avail.
  if [ ! -d /data/media/$usrchk ]; then
   echo "err: invalid dual user specified"
   exit
  fi
  ;;
 esac
 
 # Env check completed
 
}


clone() {

 # Loads def dual user:
 dualusr=`cat $cfgfile`

 # Installs package to dual user:
 pm install -r --user $dualusr `pm path $1|awk -F':' '{print $2}'`

}

help() {
 
 echo "APPCLONE - allow us to install all apps to dual user without limits"
 echo "Usage: appclone [Package Name]"
 echo "Powered by Ayaka7452"

}

# Check env
envchk

# CLI Handler:
case $1 in
help)
 help
;;
"")
 echo "err: package name not specified"
 exit
;;
*)
 clone $1
;;
esac

exit
